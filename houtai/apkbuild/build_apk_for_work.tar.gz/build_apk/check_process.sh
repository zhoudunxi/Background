#!/bin/bash

ps aux | grep -v grep | grep apk_build_Consume
if [[ $? -ne 0 ]];then
	echo "$(date +'%Y-%m-%d %H:%M:%S') -error--check th apk_build_Consume process is Down! Now restart!" >> /data/build_apk/logs/apk_buil_consume.log 
	su - apache -c 'cd /data/build_apk/ && nohup python apk_build_Consume.py >> /data/build_apk/logs/apk_buil_consume.log 2>&1 &'
fi	

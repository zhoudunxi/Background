#!/bin/env python
#coding: utf-8
#消费cdn

import os, time, multiprocessing, pika, MySQLdb, logging
from  PurgeCdn import PurgeCdn #cdn 更新
from ConfigParser import ConfigParser as Config


#读取配置文件
config_file = os.getcwd() + os.sep + 'configs' + os.sep + 'BuildApk.conf' 
conf = Config()
conf_temp = conf.read(config_file)
if not conf_temp:
        print('\033[31mConfigure file: %s  is not find\033[0m'%config_file)
        sys.exit(2)

#apk访问域名
pre_url = conf.get('default','pre_url')

#消息队列服务器配置
RabbitMQIP = conf.get('RabbitMQ','mqhost')
RabbitMQPort = conf.get('RabbitMQ','mqport')
RabbitMQUser = conf.get('RabbitMQ','mquser')
RabbitMQPWD = conf.get('RabbitMQ','mqpwd')
credentials = pika.PlainCredentials(RabbitMQUser, RabbitMQPWD)
#APKqueue = conf.get('RabbitMQ','apkqueue') #apk制作的队列名
CDNqueue = conf.get('RabbitMQ','cdnqueue') #刷新CDN的队列名
Process = int(conf.get('RabbitMQ','process')) #开启多进程，这里是进程数，一个进程对应一个work
queue_priority = {'x-max-priority':100} #队列优先级

Process = 2 #进程数,这里一次执行20条

#myslq 服务器的配置
dbhost = conf.get('mysqlDB', 'dbhost')
dbport = conf.get('mysqlDB', 'dbport')
dbuser = conf.get('mysqlDB', 'dbuser')
dbpwd = conf.get('mysqlDB', 'dbpwd')
dbdatabase = conf.get('mysqlDB', 'database')

#打印日志
loglevel = conf.get('logging', 'level')
if loglevel == 'INFO':
	loglevel = logging.INFO
elif loglevel == 'WARNING':
	loglevel = logging.WARNING
elif loglevel == 'ERROR':
	loglevel = logging.ERROR
elif loglevel == 'CRITICAL':
	loglevel = logging.CRITICAL
else:
	loglevel = logging.DEBUG
logging.basicConfig(level=loglevel,
	format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
	datefmt='%a,%Y-%-m-%d %H:%M:%S')

def update_db(sql_command):
	try:
		conn = MySQLdb.connect(host=dbhost,port=int(dbport),user=dbuser,passwd=dbpwd,db=dbdatabase) #连接mysql数据库
		cursor = conn.cursor() #光标
		cursor.execute(sql_command) #需要执行的SQL命令
		cursor.close() #光标关闭
		conn.commit() #执行SQL，如果不写，实际上是不会执行SQL的 
		conn.close() # 关闭MYSQL连接

	except:
		logging.error('Mysql server %s:%s Not to connect' %(dbhost, dbport))
def callback(ch, method, props, body):
	ITme = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
	#print("%s Received %r" %(ITme, body))
	
	split_body = body.split(":") #分隔 --> 消息ID：版本号：渠道标识：优先级：项目名：是否新文件
	if int(split_body[5]) == 1:
		#刷新CDN
		cdn = PurgeCdn()
		status = cdn.baishan('url', pre_url + split_body[2] + '/%s.apk' %split_body[4])
		status1 = cdn.qiniu('url', pre_url + split_body[2] + '/%s.apk' %split_body[4])
		#status = 0
		if status == 0 and status1 == 0:
			#消费状态写入数据库,标志着CDN更新成功
			update_renew_status = "update apkbuild_apk_message_detail set cdn_renew_status='1' where id='%d'" %int(split_body[0])
			update_db(update_renew_status)
		else:
			#print 'cdn刷新失败，系统稍后尝试再次更新'
			logging.warning('(%s) CDN refresh failure, the system try to update again later' %split_body[2])
			sys.exit(2)
	else:
		logging.info('(%s) packaging Refresh the new file is not required for CDN!' %split_body[2])	
	#消费状态写入数据库,标志着渠道包已经完全更新成功
	Now_Time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
	update_done ="update apkbuild_apk_message_detail set all_done='1',done_time='%s' where id='%d'" %(Now_Time, int(split_body[0]))
	update_db(update_done)
	
	ch.basic_ack(delivery_tag = method.delivery_tag) #回复ACK给rabbitmq, 告诉生成者，消息处理完成
	ch.close()
	logging.warning('(%s) packaging and refresh the CDN success' %split_body[2])	
def CDNconsumer():
	#try:
		connection = pika.BlockingConnection(pika.ConnectionParameters(RabbitMQIP,int(RabbitMQPort),'/',credentials))
		channel = connection.channel()
		channel.basic_qos(prefetch_count=1)
		channel.basic_consume(
			callback,
			queue=CDNqueue,
		)
		connection.process_data_events()
		connection.close()
	#except:
	#	logging.error('ERROR-%s:%s-RabbitMQ server unable to connect' %(RabbitMQIP, RabbitMQPort))
#print "[-start-] 开始执行"
#CDNconsumer()

Pool = multiprocessing.Pool(Process)
Count = 1
while Count <= Process:
	Pool.apply_async(CDNconsumer)
	Count += 1
Pool.close()
Pool.join()
